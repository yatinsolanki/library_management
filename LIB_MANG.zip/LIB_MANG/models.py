from db import db
from datetime import date
from flask_login import UserMixin


class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default="Available")
    description = db.Column(db.String(200),default=True)
    # published_date = db.Column(db.Date, nullable=True, default=date.today())

    book = db.relationship('Borrow', backref='Book',lazy= True)
    def __repr__(self):
        return f"Book('{self.title}', '{self.author}')"

class User(UserMixin,db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(20),nullable=False)

    user = db.relationship('Borrow', backref='User',lazy=True)
    def __repr__(self):
        return f"User('{self.username}', '{self.email}')"
    
class Borrow(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'), nullable=False)
    borrow_date = db.Column(db.DateTime, nullable=False, default=date.today())
    return_date = db.Column(db.DateTime, nullable=True)


    def __repr__(self):
        return f"Borrow('{self.user.username}', '{self.book.title}', '{self.borrow_date}', '{self.return_date}')"














        # {% with messages = get_flashed_messages() %}
        #       {% if messages %}
        #       {% for message in messages %}
        #       {% set category = 'success' %}
        #       {% if 'error' in message %}
        #       {% set category = 'danger' %}
        #       {% endif %}
        #       <div id="flash-message" class="alert alert-{{ category }}" role="alert">
        #         {{ message }}
        #       </div>
        #       {% endfor %}
        #       {% endif %}
        #       {% endwith %}